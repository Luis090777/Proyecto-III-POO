package TamaApp;

// Esta es la clase que usamos para crear el objeto duenno con el json

public class Duenno {
    private String nombre ;
    private  Tamagotchu[] mascotas;


Duenno(){
nombre = "juan";
}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Tamagotchu[] getMascotas() {
        return mascotas;
    }

    public void setMascotas(Tamagotchu[] mascotas) {
        this.mascotas = mascotas;
    }
}