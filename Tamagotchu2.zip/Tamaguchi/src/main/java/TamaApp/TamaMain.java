package TamaApp;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;


public class TamaMain extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    // Aqui hacemos un reloj que actualiza usan otras clases para actualizar el estado de nuestras mascotas

    public static int  minutos = 0;
    public  static int horas = -1;
    public  static String relojStatus;
    public  static String dia = "lun.";





    private void initClock(){

        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {




            if (horas == 24){

                horas = 0;
                switch (dia){
                    case("lun."): dia = "mart.";
                        break;
                    case("mart."): dia = "miérc.";
                        break;
                    case ("miérc."): dia = "juev.";
                        break;
                    case ("juev."): dia = "vier.";
                        break;
                    case ("vier."): dia = "sáb.";
                        break;
                    case ("sáb."): dia = "dom.";
                        break;
                    case ("dom."): dia = "lun.";
                        break;


                }}


            if(horas >= 13){relojStatus = " PM";}else{relojStatus = " AM";}
            horas++;



        }),
                new KeyFrame(Duration.seconds(5))

        );
        clock.setCycleCount(Animation.INDEFINITE);
        clock.play();
    }

    @Override
    public void start(Stage stage) throws Exception {
        initClock();
        Parent root = FXMLLoader.load(getClass().getResource("/tama.fxml"));
        stage.setTitle("Tamagotchi");

        stage.setScene(new Scene(root, 629, 747));
        stage.show();

        Platform.setImplicitExit(true);
        stage.setOnCloseRequest(e -> {
            Platform.exit();
            System.exit(0);
        });
    }
}
