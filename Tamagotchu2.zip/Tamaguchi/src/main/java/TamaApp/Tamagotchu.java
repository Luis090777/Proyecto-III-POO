package TamaApp;
// Clase
public class Tamagotchu {

    private String nombre;
    private String imagen;
    private int salud;
    private int felicidad;
    private int hambre;
    private int suciedad;
    private int  horasDeComida[];
    private int  horasDeMedicación[];
    private int  horasDeAseo[];
    private int  horasDeAtencion[];
    private boolean mostrar;

    public void setEstaLimpio(boolean estaLimpio) {
        this.estaLimpio = estaLimpio;
    }

    public void setEstaMuerto(boolean estaMuerto) {
        this.estaMuerto = estaMuerto;
    }

    public boolean isMostrar() {
        return mostrar;
    }

    public void setMostrar(boolean mostrar) {
        this.mostrar = mostrar;
    }

    private boolean estaCurado;
    private boolean estaAlimentado;
    private boolean estaAcariciado;
    private boolean estaLimpio;
    private  boolean estaMuerto;

// Hay muchos getters y setters inutiles que ocupa el jackson para hacer su magia

    public int[] getHorasDeComida() {
        return horasDeComida;
    }

    public int[] getHorasDeAseo() {
        return horasDeAseo;
    }

    public int[] getHorasDeMedicación() {
        return horasDeMedicación;
    }

    public boolean isEstaLimpio() {
        return estaLimpio;
    }

    public boolean isEstaAcariciado() {
        return estaAcariciado;
    }

    public boolean isEstaAlimentado() {
        return estaAlimentado;
    }

    public boolean isEstaCurado() {
        return estaCurado;
    }

    public int[] getHorasDeAtencion() {
        return horasDeAtencion;
    }



    public String getImagen() {
        return imagen;
    }

    Tamagotchu() {
    }



    void setName(String s) {
        nombre = s;
    }



    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public void setSalud(int salud) {
        this.salud = salud;
    }

    public void setFelicidad(int felicidad) {
        this.felicidad = felicidad;
    }

    public void setHambre(int hambre) {
        this.hambre = hambre;
    }

    public void setSuciedad(int suciedad) {
        this.suciedad = suciedad;
    }

    public void setHorasDeComida(int[] horasDeComida) {
        this.horasDeComida = horasDeComida;
    }

    public void setHorasDeMedicación(int[] horasDeMedicación) {
        this.horasDeMedicación = horasDeMedicación;
    }

    public void setHorasDeHaceo(int[] horasDeHaceo) {
        this.horasDeAseo = horasDeHaceo;
    }

    public void setHorasDeAtencion(int[] horasDeAtencion) {
        this.horasDeAtencion = horasDeAtencion;
    }

    public void setEstaCurado(boolean estaCurado) {
        this.estaCurado = estaCurado;
    }

    public void setEstaAlimentado(boolean estaAlimentado) {
        this.estaAlimentado = estaAlimentado;
    }

    public void setEstaAcariciado(boolean estaAcariciado) {
        this.estaAcariciado = estaAcariciado;
    }

    String getName() {
        return nombre;
    }

    int getSalud() { return salud;}
    int getHambre() { return hambre;}
    int getSuciedad() { return suciedad;}
    int getFelicidad() { return felicidad;}

    // Al tocar el boton de limpiar, se devuelve la suciedad a 0 y la felicidad aumenta

    private void adjustSuciedad() {
        if (estaLimpio==true){}else{

            suciedad = 0;
            if(felicidad >= 5){
                felicidad = 5;}
            else{felicidad++;}

            if(suciedad >= 5){
                suciedad = 5;}

            else if(suciedad <= 0){
                suciedad = 0;}
            estaLimpio = true;}
    }
    // Al tocar el boton de alimentar ,se devuelve el hambre a 0
    private void adjustHambre() {
        if (estaAlimentado==true){}else{

            hambre = 0;

            if(hambre >= 5)
                hambre = 5;

            else if(hambre <= 0){
                hambre = 0;}
            estaAlimentado = true;}
    }

// acariciar aumenta la felicidad
    private void adjustAcariciar() {
        if (estaAcariciado==true){}else{

            felicidad++;

            if(felicidad >= 5){
                felicidad = 5;}

            else if(felicidad <= 0){
                felicidad = 5; }

            estaAcariciado = true;}
    }

    // cura a la mascota y le aumenta la salud
    private void adjustSalud() {
        if (estaCurado==true){}else{

            salud++;

            if(salud >= 5){
                salud = 5;}

            else if(salud <= 0){
                salud = 0; }

            estaCurado = true;}
    }




// Esta funcion es la que baja las estadisticas de las mascotas si no se les atiende
    private void decayStats(int hora){


        int i,x;
        for (i = 0; i < 3; i++) {
            x = horasDeAseo[i];
            if(x == hora){ estaLimpio = false;}

            if(estaLimpio== false && hora > x+1)
            {suciedad++;
            if (suciedad == 5 ){morir();}
                if (salud != 0){
                    salud--; }}

        }

        for (i = 0; i < 3; i++) {
        x = horasDeComida[i];
        if(x == hora){estaAlimentado = false;}

        if(estaAlimentado== false && hora > x+1)
        {hambre++;
            if (salud != 0){
            salud--;
             }}}


        for (i = 0; i < horasDeMedicación.length; i++) {
            x = horasDeMedicación[i];
            if(x == hora){estaCurado = false;}

            if(estaCurado == false && hora > x+1)
            {
                if (salud != -2){
            salud--;}
                else if (salud == -2){morir();}
            }
        }



        for (i = 0; i < horasDeAtencion.length; i++) {
            x = horasDeAtencion[i];
            if(x == hora){estaAcariciado = false;}

            if(estaAcariciado== false && hora > x+1)
            {
                if(felicidad != 0){
                felicidad--; } }}




    }
        //======================================

    // Estas son las funciones que llaman los handles de los botones

   void actualizarEstado(int hora){
        decayStats(hora);
   }
    void alimentar() {
        adjustHambre();
    }
    void limpiar(){
        adjustSuciedad();
    }
    void acariciar() {
        adjustAcariciar();
    }

    public boolean isEstaMuerto() {
        return estaMuerto;
    }

    void sanar() {
        adjustSalud();
    }
    // Esta es la funcion que se muera o  que se escape nuestra mascota
    void morir(){
        estaMuerto = true;
        if (salud == -2){
        System.out.println("Su mascota " + nombre + " ha muerto " );}
        if (suciedad == 5){System.out.println("Su mascota " + nombre + " se ha escapado ");}}


}


