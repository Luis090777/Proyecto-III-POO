package TamaApp;
// Launcher del fx
public class FXLauncher {

    public static void main(String[] args) {
        TamaMain.main(args);
    }

}
