package TamaApp;
// Clase que funciona como contador global de puntos
public class Puntos {
    public static int getPuntos() {
        return puntos;
    }

    static int puntos;

    Puntos(){
        puntos=0;
    }

    static void actualizarPuntos(Tamagotchu tamagotchu){
        if(tamagotchu.getFelicidad() > 3 ){puntos = puntos + 10;}
        else if (tamagotchu.getFelicidad() <= 3 ){puntos = puntos - 10;}

        if(tamagotchu.getSalud() == 5 ){puntos = puntos + 10;}
        else if (tamagotchu.getSalud() >= 2 ){puntos = puntos - 10;}

        if(tamagotchu.getSuciedad() >= 4 ){puntos = puntos - 10;}

        if(tamagotchu.getHambre() < 4 ){puntos = puntos + 10;}
    }
}
