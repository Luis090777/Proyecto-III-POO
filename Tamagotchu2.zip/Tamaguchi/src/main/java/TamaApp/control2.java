package TamaApp;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import java.io.File;
import java.io.IOException;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import javafx.scene.image.Image;
import java.net.URL;
import java.util.ResourceBundle;
import com.fasterxml.jackson.databind.ObjectMapper;
public class control2 implements Initializable {

    // constante
    int SHORT_MESSAGE = 3;

    // Esto son los elementos de la escena que tocan el código
    @FXML
    Label puntos;

    @FXML
    Label owner;

    @FXML
    Label name;


    @FXML
    Label time;



    @FXML
    Label message;

    @FXML
    ImageView tamaImage;

    @FXML
    ImageView relojImagen;

    @FXML
    ImageView iconoHambre;

    @FXML
    ImageView iconoSuciedad;

    @FXML
    ImageView iconoSalud;

    @FXML
    ImageView iconoFelicidad;

    @FXML
    ImageView imagenGif;

    @FXML
    Button botonAlimentar;
    @FXML
    Button botonLimpiar;
    @FXML
    Button botonAcariciar;
    @FXML
    Button botonSanar;

    @FXML
    ProgressBar barraHambre;
    @FXML
    ProgressBar barraSuciedad;
    @FXML
    ProgressBar barraSalud;
    @FXML
    ProgressBar barraFelicidad;



    // 2 mappers para los json
    ObjectMapper mapper = new ObjectMapper();


    // Se crean objetos tamaguchi con los datos de los Jsons
    public  Duenno duenno = mapper.readValue(new File("C:\\Users\\Luis Alfaro\\Desktop\\Tamaguchi\\src\\main\\resources\\jsons\\Tamaguchi.json"), Duenno.class);




    // Se crea un array de mascotas

    // imagenes para el estado de las necesoi
    Image check = new Image("images/check.png");
    Image warning = new Image("images/advertencia.png");


    public control2() throws IOException {
    }

    // Esta funcion actualiza con el reloj de main los stats de las mascotas
    private void actualizarTamaguchi(){

        Timeline actualizarStats = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            int i;
            for (i = 0; i < duenno.getMascotas().length; i++) {

                if( duenno.getMascotas()[i].isEstaMuerto() == true){}
                else{

                    duenno.getMascotas()[i].actualizarEstado(TamaMain.horas);



            if (TamaMain.horas == 12){
            Puntos.actualizarPuntos(duenno.getMascotas()[i]);}}
            }

            if(duenno.getMascotas()[0].isEstaMuerto() == true && duenno.getMascotas()[1].isEstaMuerto() == true){
                System.out.println("Todas sus mascotas han muerto");
                Platform.exit();
                System.exit(0); }



        }),
                new KeyFrame(Duration.seconds(5))

        );
        actualizarStats.setCycleCount(Animation.INDEFINITE);
        actualizarStats.play();

    }

    // Muestra la mascota que tenga el boolean mostar en true
    private void mostrarTamaguchi(){


                Timeline actualizarGUI = new Timeline(new KeyFrame(Duration.ZERO, e -> {
                     int i, x;
                    for (i = 0; i < duenno.getMascotas().length; i++) {
                        x = i ;

                        if(duenno.getMascotas()[x].isMostrar() == true){
                            Image imagen1 = new Image(duenno.getMascotas()[x].getImagen());
                            tamaImage.setImage(imagen1);


                            Image imagen2 = new Image("images/clock1.png");

                            relojImagen.setImage(imagen2);
                            name.setText(duenno.getMascotas()[x].getName());
                            owner.setText(duenno.getNombre());
                            if(duenno.getMascotas()[x].isEstaLimpio()){iconoSuciedad.setImage(check);}else{iconoSuciedad.setImage(warning);}
                            if(duenno.getMascotas()[x].isEstaCurado()){iconoSalud.setImage(check);}else{iconoSalud.setImage(warning);}
                            if(duenno.getMascotas()[x].isEstaAlimentado()){iconoHambre.setImage(check);}else{iconoHambre.setImage(warning);}
                            if(duenno.getMascotas()[x].isEstaAcariciado()){iconoFelicidad.setImage(check);}else{iconoFelicidad.setImage(warning);}
                            time.setText(TamaMain.dia +" "+ TamaMain.horas + ":" + TamaMain.minutos + TamaMain.relojStatus);

                            barraHambre.setProgress(duenno.getMascotas()[x].getHambre()*0.2);
                            barraFelicidad.setProgress(duenno.getMascotas()[x].getFelicidad()*0.2);
                            barraSalud.setProgress(duenno.getMascotas()[x].getSalud()*0.2);
                            barraSuciedad.setProgress(duenno.getMascotas()[x].getSuciedad()*0.2);
                            puntos.setText(String.valueOf(Puntos.puntos));



                        if (duenno.getMascotas()[x].isEstaMuerto() == true){
                            Image muerto = new Image("images/muerto.jpg");

                            tamaImage.setImage(muerto);




                            relojImagen.setImage(muerto);
                            name.setText("muerto");
                            owner.setText(duenno.getNombre());
                            if(duenno.getMascotas()[x].isEstaLimpio()){iconoSuciedad.setImage(muerto);}else{iconoSuciedad.setImage(muerto);}
                            if(duenno.getMascotas()[x].isEstaCurado()){iconoSalud.setImage(muerto);}else{iconoSalud.setImage(muerto);}
                            if(duenno.getMascotas()[x].isEstaAlimentado()){iconoHambre.setImage(muerto);}else{iconoHambre.setImage(muerto);}
                            if(duenno.getMascotas()[x].isEstaAcariciado()){iconoFelicidad.setImage(muerto);}else{iconoFelicidad.setImage(muerto);}
                            time.setText(TamaMain.dia +" "+ TamaMain.horas + ":" + TamaMain.minutos + TamaMain.relojStatus);

                            barraHambre.setProgress(0);
                            barraFelicidad.setProgress(0);
                            barraSalud.setProgress(0);
                            barraSuciedad.setProgress(0);

                            puntos.setText(String.valueOf(Puntos.puntos));
                        }}
                    }

                }),
                        new KeyFrame(Duration.seconds(0.1))

                );



                actualizarGUI.setCycleCount(Animation.INDEFINITE);
                actualizarGUI.play();

    }






    @Override
    // inicializa el controlador
    public void initialize(URL location, ResourceBundle resources) {

        actualizarTamaguchi();
        mostrarTamaguchi();


    }
// esto lo activa el boton de alimentar, alimenta a la mascota si es su hora de comida y muestra una "animacion"

    public void handleFeed() {
        Image imagenAlimentar = new Image("images/alimentar.gif");
        int i;
        for (i = 0; i < duenno.getMascotas().length; i++) {
            if (duenno.getMascotas()[i].isMostrar() == true){
                duenno.getMascotas()[i].alimentar();

                if(duenno.getMascotas()[i].isEstaMuerto() == true){
                    displayMessage("Ya es muy tarde para hacer eso "+ duenno.getMascotas()[i].getName()+ " está muert@" , SHORT_MESSAGE);}
                else{displayGif(imagenAlimentar,SHORT_MESSAGE);
                    displayMessage("alimentó a: "+ duenno.getMascotas()[i].getName(), SHORT_MESSAGE); }
            } }
    }
    // esto lo activa el boton de sanar, cura a la mascota si es su hora de su medicina y muestra una "animacion"
    public void handleSanar() {
        Image imagenCurar = new Image("images/curar.gif");
        int i;
        for (i = 0; i < duenno.getMascotas().length; i++) {
            if (duenno.getMascotas()[i].isMostrar() == true){
                duenno.getMascotas()[i].sanar();

                if(duenno.getMascotas()[i].isEstaMuerto() == true){
                    displayMessage("Ya es muy tarde para hacer eso "+ duenno.getMascotas()[i].getName()+ " está muert@" , SHORT_MESSAGE);}
                else{displayGif(imagenCurar,SHORT_MESSAGE);
                    displayMessage("Sanó a: "+ duenno.getMascotas()[i].getName(), SHORT_MESSAGE); }
                } }
        }



    // esto lo activa el boton de acariciar, juega con la mascota si es su hora de pedir cariño  y muestra una "animacion"
    public void handlePlay() {
        Image imagenAcariciar = new Image("images/acariciar.gif");
        int i;
        for (i = 0; i < duenno.getMascotas().length; i++) {
            if (duenno.getMascotas()[i].isMostrar() == true){
                duenno.getMascotas()[i].acariciar();

                if(duenno.getMascotas()[i].isEstaMuerto() == true){
                    displayMessage("Ya es muy tarde para hacer eso "+ duenno.getMascotas()[i].getName()+ " está muert@" , SHORT_MESSAGE);}
                else{displayGif(imagenAcariciar,SHORT_MESSAGE);
                    displayMessage("Acaricio a: "+ duenno.getMascotas()[i].getName(), SHORT_MESSAGE); }
            } }
    }


    // esto lo activa el boton de limpiar, limpia a la mascota si es su hora de haceo  y muestra una "animacion"
    public void handleLimpiar() {
        Image imagenLimpiar = new Image("images/limpiar.gif");
        int i;
        for (i = 0; i < duenno.getMascotas().length; i++) {
            if (duenno.getMascotas()[i].isMostrar() == true){
                duenno.getMascotas()[i].limpiar();

                if(duenno.getMascotas()[i].isEstaMuerto() == true){
                    displayMessage("Ya es muy tarde para hacer eso "+ duenno.getMascotas()[i].getName()+ " está muert@" , SHORT_MESSAGE);}
                else{displayGif(imagenLimpiar,SHORT_MESSAGE);
                    displayMessage("Limpió a: "+ duenno.getMascotas()[i].getName(), SHORT_MESSAGE); }
            } }
    }

// Muestra un mensaje por un periodo de tiempo
    public void displayMessage(String messageText, int duration) {
        message.setText(messageText);
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(duration), evt -> message.setVisible(false)));
        timeline.play();
        message.setVisible(true);
    }

    // Muestra una imagen por un periodo de tiempo
    public void displayGif(Image imagen, int duracion) {
        imagenGif.setImage (imagen);
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(duracion), evt -> imagenGif.setVisible(false)));
        timeline.play();
        imagenGif.setVisible(true);


    }
    // Cambia de estado de mostrar de las mascotas, esta muy alambrado porque no pude hacerlo cn iteracion y solo hay 2 mascotas
    public void handleCambio() {


            if (duenno.getMascotas()[0].isMostrar() == true){
                duenno.getMascotas()[0].setMostrar(false);
                duenno.getMascotas()[1].setMostrar(true); }

            else if(duenno.getMascotas()[1].isMostrar() == true){
                duenno.getMascotas()[1].setMostrar(false);
                duenno.getMascotas()[0].setMostrar(true);
            }}    }